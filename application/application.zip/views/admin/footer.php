<footer class="footer text-right"> 2016 © <a href="http://www.spagreen.net"> <?php echo $system_name;?></a> |
  Developed by: <a href="http://www.spagreen.net"> Spa Green Creative</a> </footer>
