<div class="container">
	<section class="page404" style="margin-top: 100px;">
	    <p class="line1">404</p>
	    <p class="line2">Look like something wrong! The page you were looking for is not here.</p>
	    <p><a href="<?php echo base_url(); ?>" class="btn btn-success">Back to Home</a></p>
	    <div><img src="<?php echo base_url(); ?>assets/front_end/images/404.jpg" alt="Page not found"></div>
	</section>
</div>
